<?php include "koneksi.php"; ?>
<!DOCTYPE html>
<html>
<head>
	<title>Upload file menggunakan php mysqli</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
	<style>
		*{
			padding: 0px;
			margin: 0px;
		}
		body{
			background-color: #007B00;
		}
		h2{
			padding: 2px;
			border-bottom: 2px solid black;
		}
		.tambah{
			background-color: #2298E6;
			text-decoration: none;
			border-radius: 5px;
			color: white;
			padding: 8px;
		}
		.tambah:active{
			background-color: white;
		}
		.isi{
			display: grid;
			grid-template-columns: repeat(3,1fr);
			gap: 1rem;
		}
		.tampilan{
			background-color: yellow;
			border-radius: 5px;
			padding: 5px;
			transition: .5s;
		}
		.tampilan:Hover{
			scale: 1.2;
			background-color: grey;
			color: white;
		}
		.tampilan img{
            object-fit: cover;
            width: 100%;
            height: 30vw;
            border-top-left-radius: .5rem;
            border-top-right-radius: .5rem;
          }
          .tampilan p{
          	text-align: center;
              margin-bottom: 5px;
          }
          .edit,
          .hapus{
			text-decoration: none;
			border-radius: 5px;
			color: white;
			padding: 2px;
          }
          .edit{
          	background-color: #2298E6;
              floating: left;
          }
          .hapus{
          	background-color:#B6000C;
              floating: right;
          }
          .edit:active,
          .hapus:active{
          	background-color: white;
              text-decoration: none;
              color: black;
          }
	</style>
</head>
<body>
	<div class="container">
		<h2 style="text-align: center;">galery</h2>		
		<br>
		<?php 
		if(isset($_GET['alert'])){
			if($_GET['alert']=='gagal_ekstensi'){
				?>
				<div class="alert alert-warning alert-dismissible">
					<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
					<h4><i class="icon fa fa-warning"></i> Peringatan !</h4>
					Ekstensi Tidak Diperbolehkan
				</div>								
				<?php
			}elseif($_GET['alert']=="gagal_ukuran"){
				?>
				<div class="alert alert-warning alert-dismissible">
					<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
					<h4><i class="icon fa fa-check"></i> Peringatan !</h4>
					Ukuran File terlalu Besar
				</div> 								
				<?php
			}elseif($_GET['alert']=="berhasil"){
				?>
				<div class="alert alert-success alert-dismissible">
					<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
					<h4><i class="icon fa fa-check"></i> Success</h4>
					Berhasil Disimpan
				</div> 								
				<?php
			}elseif($_GET['alert']=="berhasilhapus"){
				?>
				<div class="alert alert-success alert-dismissible">
					<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
					<h4><i class="icon fa fa-check"></i> Success</h4>
					Berhasil Dihapus
				</div> 								
				<?php
			}
		}
		?>
		<br>
		<a href="tambah_galeri.php" class="tambah">+ Gambar</a>
		<br>		
		<br>
		<div class="isi">
		<?php
		$data = mysqli_query($link,"select * from galeri");
			while($d = mysqli_fetch_array($data)){
				?>
				<div class="tampilan">
				<img class="img" src="../fotogaleri/<?php echo $d['gambar'] ?>">
					<p><?php echo $d['judul']?></p>
					<a href="edit_galeri.php?id=<?php echo $d['no'];?>" class="edit">edit</a>
					<a href="hapus_galeri.php?id=<?php echo $d['no'];?>" class="hapus">hapus</a>
				</div>
				<?php
		    }
		?>
		</div>
	</div>
</body>
</html>
